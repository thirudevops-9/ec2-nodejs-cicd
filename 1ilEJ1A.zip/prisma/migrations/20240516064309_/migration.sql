-- AlterTable
ALTER TABLE "Appointment" ALTER COLUMN "apptTime" SET DATA TYPE TIME;
