-- AlterTable
ALTER TABLE "Reminder" ADD COLUMN     "isSensitive" BOOLEAN NOT NULL DEFAULT false;
