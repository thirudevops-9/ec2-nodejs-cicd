-- AlterTable
ALTER TABLE "Users" ALTER COLUMN "refreshToken" DROP NOT NULL;
