-- AlterTable
ALTER TABLE "Users" ADD COLUMN     "refreshToken" TEXT NOT NULL DEFAULT '';
