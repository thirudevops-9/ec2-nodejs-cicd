# !/bin/bash

# navigate to app folder
cd /root/nodjes
pm2 start src/index.js

